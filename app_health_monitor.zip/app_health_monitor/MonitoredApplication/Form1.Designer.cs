﻿namespace MonitoredApplication
{
    partial class MonitoredApplicationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_lockWatchDog = new System.Windows.Forms.Button();
            this.btn_Terminate = new System.Windows.Forms.Button();
            this.btn_KillWatchDog = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // btn_lockWatchDog
            // 
            this.btn_lockWatchDog.Location = new System.Drawing.Point(19, 444);
            this.btn_lockWatchDog.Margin = new System.Windows.Forms.Padding(4);
            this.btn_lockWatchDog.Name = "btn_lockWatchDog";
            this.btn_lockWatchDog.Size = new System.Drawing.Size(144, 28);
            this.btn_lockWatchDog.TabIndex = 0;
            this.btn_lockWatchDog.Text = "Start Process";
            this.btn_lockWatchDog.UseVisualStyleBackColor = true;
            this.btn_lockWatchDog.Click += new System.EventHandler(this.btn_lockWatchDog_Click);
            // 
            // btn_Terminate
            // 
            this.btn_Terminate.Location = new System.Drawing.Point(391, 444);
            this.btn_Terminate.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Terminate.Name = "btn_Terminate";
            this.btn_Terminate.Size = new System.Drawing.Size(100, 28);
            this.btn_Terminate.TabIndex = 1;
            this.btn_Terminate.Text = "Close";
            this.btn_Terminate.UseVisualStyleBackColor = true;
            this.btn_Terminate.Click += new System.EventHandler(this.btn_Terminate_Click);
            // 
            // btn_KillWatchDog
            // 
            this.btn_KillWatchDog.Location = new System.Drawing.Point(183, 444);
            this.btn_KillWatchDog.Margin = new System.Windows.Forms.Padding(4);
            this.btn_KillWatchDog.Name = "btn_KillWatchDog";
            this.btn_KillWatchDog.Size = new System.Drawing.Size(144, 28);
            this.btn_KillWatchDog.TabIndex = 2;
            this.btn_KillWatchDog.Text = "Kill Process";
            this.btn_KillWatchDog.UseVisualStyleBackColor = true;
            this.btn_KillWatchDog.Click += new System.EventHandler(this.btn_KillWatchDog_Click);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(19, 25);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(472, 398);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // MonitoredApplicationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 494);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btn_KillWatchDog);
            this.Controls.Add(this.btn_Terminate);
            this.Controls.Add(this.btn_lockWatchDog);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MonitoredApplicationForm";
            this.Text = "Application Health Monitor";
            this.Load += new System.EventHandler(this.MonitoredApplicationForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_lockWatchDog;
        private System.Windows.Forms.Button btn_Terminate;
        private System.Windows.Forms.Button btn_KillWatchDog;
        private System.Windows.Forms.ListView listView1;
    }
}

